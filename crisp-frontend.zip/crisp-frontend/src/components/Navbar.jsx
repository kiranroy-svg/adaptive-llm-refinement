function Navbar() {
  return (
    <header className="flex h-16 items-center justify-between border-b border-slate-800 bg-slate-950 px-8">

      {/* Page identity */}
      <div>
        <h2 className="text-lg font-semibold text-white">
          CRISP Assistant
        </h2>

        <p className="text-xs text-slate-500">
          Intelligent Response Improvement
        </p>
      </div>

      {/* System status */}
      <div className="flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900 px-4 py-2">

        <span className="h-2 w-2 rounded-full bg-green-500"></span>

        <span className="text-sm text-slate-400">
          System Online
        </span>

      </div>

    </header>
  )
}

export default Navbar