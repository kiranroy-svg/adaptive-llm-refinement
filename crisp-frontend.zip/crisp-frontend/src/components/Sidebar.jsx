import { NavLink, useNavigate } from "react-router-dom"

function Sidebar() {
  const navigate = useNavigate()

  const navItemClass = ({ isActive }) =>
    `w-full rounded-lg px-4 py-3 text-left text-sm font-medium transition ${
      isActive
        ? "bg-purple-600 text-white"
        : "text-slate-400 hover:bg-slate-800 hover:text-white"
    }`

  return (
    <aside className="flex h-screen w-64 flex-col border-r border-slate-800 bg-slate-950 px-4 py-6">

      {/* Logo */}
      <div className="mb-8 px-3">

        <button
          onClick={() => navigate("/assistant")}
          className="text-left"
        >
          <h1 className="text-2xl font-bold text-white">
            CRISP
          </h1>

          <p className="mt-1 text-xs text-slate-500">
            Response Improvement System
          </p>
        </button>

      </div>


      {/* Main Navigation */}
      <nav className="flex-1 space-y-2">

        <NavLink
          to="/assistant"
          className={navItemClass}
        >
          Assistant
        </NavLink>


        <NavLink
          to="/initial-response"
          className={navItemClass}
        >
          Response Flow
        </NavLink>


        <NavLink
          to="/final-response"
          className={navItemClass}
        >
          Final Response
        </NavLink>


        <button
          disabled
          className="w-full cursor-not-allowed rounded-lg px-4 py-3 text-left text-sm text-slate-600"
        >
          History
        </button>

      </nav>


      {/* Pipeline Status */}
      <div className="mb-4 rounded-xl border border-slate-800 bg-slate-900 p-4">

        <div className="flex items-center gap-2">

          <span className="h-2 w-2 rounded-full bg-green-500" />

          <span className="text-xs font-medium text-slate-300">
            CRISP System Online
          </span>

        </div>

        <p className="mt-2 text-xs leading-5 text-slate-600">
          Response improvement pipeline is ready.
        </p>

      </div>


      {/* Bottom Navigation */}
      <div className="space-y-2 border-t border-slate-800 pt-4">

        <button
          disabled
          className="w-full cursor-not-allowed rounded-lg px-4 py-3 text-left text-sm text-slate-600"
        >
          Settings
        </button>


        <button
          onClick={() => navigate("/")}
          className="w-full rounded-lg px-4 py-3 text-left text-sm text-slate-400 transition hover:bg-slate-800 hover:text-white"
        >
          Exit to Home
        </button>

      </div>

    </aside>
  )
}

export default Sidebar