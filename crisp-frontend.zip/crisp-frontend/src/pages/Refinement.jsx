import { useNavigate } from "react-router-dom"

function Refinement() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Response Refinement
          </h1>

          <span className="rounded-full bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-400">
            Iteration 1
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          CRISP is refining the response based on the critique and evaluation.
        </p>
      </div>


      {/* Progress */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="flex items-center justify-between">

          <div>
            <p className="text-sm text-slate-500">
              Refinement Progress
            </p>

            <p className="mt-1 text-lg font-semibold text-white">
              Iteration 1 of 3
            </p>
          </div>

          <span className="rounded-full bg-blue-500/10 px-3 py-1 text-sm text-blue-400">
            Processing
          </span>

        </div>


        <div className="mt-5 h-2 overflow-hidden rounded-full bg-slate-800">

          <div
            className="h-full rounded-full bg-purple-600"
            style={{ width: "45%" }}
          />

        </div>

        <p className="mt-2 text-right text-xs text-slate-500">
          45% complete
        </p>

      </div>


      {/* Timeline */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          Refinement Timeline
        </h2>

        <p className="mt-1 text-sm text-slate-500">
          Track how the response changes during the refinement process.
        </p>


        <div className="relative mt-8">

          {/* Timeline line */}
          <div className="absolute left-5 top-2 bottom-2 w-px bg-slate-800" />


          {/* Initial response */}
          <div className="relative flex gap-5 pb-10">

            <div className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-700 bg-slate-950 text-sm font-semibold text-slate-400">
              0
            </div>

            <div className="flex-1 rounded-xl border border-slate-800 bg-slate-950 p-5">

              <div className="flex items-center justify-between">

                <h3 className="font-semibold text-white">
                  Initial Response
                </h3>

                <span className="text-sm text-slate-500">
                  Score: 87
                </span>

              </div>

              <p className="mt-2 text-sm leading-6 text-slate-500">
                Original response generated before refinement.
              </p>

            </div>

          </div>


          {/* Iteration 1 */}
          <div className="relative flex gap-5 pb-10">

            <div className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-purple-500/40 bg-purple-500/10 text-sm font-semibold text-purple-400">
              1
            </div>

            <div className="flex-1 rounded-xl border border-purple-500/20 bg-purple-500/5 p-5">

              <div className="flex items-center justify-between">

                <div className="flex items-center gap-3">

                  <h3 className="font-semibold text-white">
                    Refinement Iteration 1
                  </h3>

                  <span className="rounded-full bg-purple-500/10 px-2 py-1 text-xs text-purple-400">
                    Active
                  </span>

                </div>

                <span className="text-sm text-purple-400">
                  Improving
                </span>

              </div>


              <p className="mt-3 text-sm leading-6 text-slate-400">
                The response is being improved using the identified
                weaknesses and suggestions from the critique.
              </p>


              <div className="mt-4 grid gap-3 sm:grid-cols-3">

                <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">

                  <p className="text-xs text-slate-500">
                    Added
                  </p>

                  <p className="mt-1 text-sm text-slate-300">
                    Practical examples
                  </p>

                </div>


                <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">

                  <p className="text-xs text-slate-500">
                    Improved
                  </p>

                  <p className="mt-1 text-sm text-slate-300">
                    Reasoning depth
                  </p>

                </div>


                <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">

                  <p className="text-xs text-slate-500">
                    Expanded
                  </p>

                  <p className="mt-1 text-sm text-slate-300">
                    Completeness
                  </p>

                </div>

              </div>

            </div>

          </div>


          {/* Next evaluation */}
          <div className="relative flex gap-5">

            <div className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-700 bg-slate-950 text-sm font-semibold text-slate-500">
              2
            </div>

            <div className="flex-1 rounded-xl border border-dashed border-slate-800 bg-slate-950 p-5">

              <h3 className="font-semibold text-slate-400">
                Re-evaluation
              </h3>

              <p className="mt-2 text-sm text-slate-600">
                The refined response will be evaluated again.
              </p>

            </div>

          </div>

        </div>

      </div>


      {/* Current status */}
      <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 p-5">

        <div>

          <p className="text-sm font-medium text-white">
            Refinement is in progress
          </p>

          <p className="mt-1 text-sm text-slate-500">
            CRISP will re-evaluate the improved response.
          </p>

        </div>

        <div className="h-2 w-2 animate-pulse rounded-full bg-blue-400" />

      </div>


      {/* Continue */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/comparison")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          View Comparison →
        </button>

      </div>

    </div>
  )
}

export default Refinement