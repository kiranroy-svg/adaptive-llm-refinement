import { useNavigate } from "react-router-dom"

function Critique() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Response Critique
          </h1>

          <span className="rounded-full bg-purple-500/10 px-3 py-1 text-xs font-medium text-purple-400">
            Analysis Complete
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          CRISP has analyzed the response and identified areas for improvement.
        </p>
      </div>


      {/* Critique Summary */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          Critique Summary
        </h2>

        <p className="mt-3 leading-7 text-slate-400">
          The response is generally clear and accurate, but it can be
          improved by providing more specific examples, stronger reasoning,
          and a more complete explanation of the topic.
        </p>

      </div>


      {/* Strengths and Weaknesses */}
      <div className="grid gap-6 md:grid-cols-2">

        {/* Strengths */}
        <div className="rounded-2xl border border-emerald-500/20 bg-slate-900 p-6">

          <div className="flex items-center gap-3">

            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400">
              ✓
            </div>

            <h2 className="text-xl font-semibold text-white">
              Strengths
            </h2>

          </div>


          <ul className="mt-6 space-y-4">

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-emerald-400">•</span>
              The response is easy to understand and well structured.
            </li>

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-emerald-400">•</span>
              The main concepts are explained accurately.
            </li>

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-emerald-400">•</span>
              The response maintains a clear and professional tone.
            </li>

          </ul>

        </div>


        {/* Weaknesses */}
        <div className="rounded-2xl border border-red-500/20 bg-slate-900 p-6">

          <div className="flex items-center gap-3">

            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-500/10 text-red-400">
              !
            </div>

            <h2 className="text-xl font-semibold text-white">
              Weaknesses
            </h2>

          </div>


          <ul className="mt-6 space-y-4">

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-red-400">•</span>
              Some explanations lack supporting examples.
            </li>

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-red-400">•</span>
              The reasoning could be more detailed.
            </li>

            <li className="flex gap-3 text-sm leading-6 text-slate-400">
              <span className="text-red-400">•</span>
              Additional relevant information could improve completeness.
            </li>

          </ul>

        </div>

      </div>


      {/* Suggestions */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="flex items-center gap-3">

          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/10 text-blue-400">
            ✦
          </div>

          <div>

            <h2 className="text-xl font-semibold text-white">
              Suggestions for Improvement
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Recommended changes before generating the refined response.
            </p>

          </div>

        </div>


        <div className="mt-6 space-y-3">

          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4">

            <p className="text-sm text-slate-300">
              Add practical healthcare examples such as medical imaging,
              patient risk prediction, and hospital resource optimization.
            </p>

          </div>


          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4">

            <p className="text-sm text-slate-300">
              Expand the reasoning behind how AI improves clinical
              decision-making.
            </p>

          </div>


          <div className="rounded-lg border border-slate-800 bg-slate-950 p-4">

            <p className="text-sm text-slate-300">
              Include a balanced discussion of limitations and responsible
              AI use in healthcare.
            </p>

          </div>

        </div>

      </div>


      {/* Continue */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/refinement")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          Start Refinement →
        </button>

      </div>

    </div>
  )
}

export default Critique