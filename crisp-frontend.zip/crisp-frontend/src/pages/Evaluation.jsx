import { useNavigate } from "react-router-dom"

function Evaluation() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Response Evaluation
          </h1>

          <span className="rounded-full bg-blue-500/10 px-3 py-1 text-xs font-medium text-blue-400">
            Evaluation Complete
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          CRISP evaluates the response across five quality dimensions.
        </p>
      </div>


      {/* Overall Score */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">

          <div>

            <p className="text-sm text-slate-500">
              Overall Quality
            </p>

            <p className="mt-2 text-5xl font-bold text-white">
              87
              <span className="ml-2 text-lg font-normal text-slate-500">
                / 100
              </span>
            </p>

          </div>


          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 px-5 py-4">

            <p className="text-sm font-medium text-amber-400">
              Below Quality Threshold
            </p>

            <p className="mt-1 text-xs text-slate-500">
              Refinement may be required.
            </p>

          </div>

        </div>

      </div>


      {/* Evaluation Dimensions */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          Evaluation Dimensions
        </h2>

        <p className="mt-1 text-sm text-slate-500">
          Individual scores assigned by the CRISP evaluator.
        </p>


        <div className="mt-6 space-y-6">


          {/* Accuracy */}
          <div>

            <div className="mb-2 flex items-center justify-between">

              <span className="text-sm text-slate-400">
                Accuracy
              </span>

              <span className="text-sm font-medium text-white">
                88 / 100
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "88%" }}
              />

            </div>

          </div>


          {/* Completeness */}
          <div>

            <div className="mb-2 flex items-center justify-between">

              <span className="text-sm text-slate-400">
                Completeness
              </span>

              <span className="text-sm font-medium text-white">
                82 / 100
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "82%" }}
              />

            </div>

          </div>


          {/* Reasoning */}
          <div>

            <div className="mb-2 flex items-center justify-between">

              <span className="text-sm text-slate-400">
                Reasoning
              </span>

              <span className="text-sm font-medium text-white">
                79 / 100
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "79%" }}
              />

            </div>

          </div>


          {/* Clarity */}
          <div>

            <div className="mb-2 flex items-center justify-between">

              <span className="text-sm text-slate-400">
                Clarity
              </span>

              <span className="text-sm font-medium text-white">
                91 / 100
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "91%" }}
              />

            </div>

          </div>


          {/* Safety */}
          <div>

            <div className="mb-2 flex items-center justify-between">

              <span className="text-sm text-slate-400">
                Safety
              </span>

              <span className="text-sm font-medium text-white">
                96 / 100
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "96%" }}
              />

            </div>

          </div>

        </div>

      </div>


      {/* Evaluation Summary */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          Evaluation Summary
        </h2>

        <p className="mt-3 leading-7 text-slate-400">
          The response performs well in clarity and safety, but the
          completeness and reasoning scores indicate that additional
          explanation and supporting examples could improve the response.
        </p>

      </div>


      {/* Action */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/decision")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          Continue to Decision →
        </button>

      </div>

    </div>
  )
}

export default Evaluation