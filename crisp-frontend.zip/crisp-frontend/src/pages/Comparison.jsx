import { useNavigate } from "react-router-dom"

function Comparison() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Response Comparison
          </h1>

          <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-400">
            Improvement Detected
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          Compare the initial response with the refined response generated
          by CRISP.
        </p>

      </div>


      {/* Quality Improvement */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">

          <div>

            <p className="text-sm text-slate-500">
              Quality Improvement
            </p>

            <div className="mt-2 flex items-baseline gap-3">

              <span className="text-4xl font-bold text-white">
                +8
              </span>

              <span className="text-sm text-emerald-400">
                points
              </span>

            </div>

            <p className="mt-2 text-sm text-slate-500">
              Overall quality increased from 87 to 95.
            </p>

          </div>


          {/* Score comparison */}
          <div className="flex items-center gap-6">

            <div className="text-center">

              <p className="text-xs text-slate-500">
                Initial
              </p>

              <p className="mt-1 text-2xl font-bold text-slate-400">
                87
              </p>

            </div>


            <div className="text-slate-600">
              →
            </div>


            <div className="text-center">

              <p className="text-xs text-slate-500">
                Refined
              </p>

              <p className="mt-1 text-2xl font-bold text-emerald-400">
                95
              </p>

            </div>

          </div>

        </div>

      </div>


      {/* Response Comparison */}
      <div className="grid gap-6 lg:grid-cols-2">

        {/* Initial Response */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

          <div className="flex items-center justify-between">

            <div>

              <h2 className="text-xl font-semibold text-white">
                Initial Response
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Before refinement
              </p>

            </div>

            <span className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-400">
              87/100
            </span>

          </div>


          <div className="mt-6 rounded-xl border border-slate-800 bg-slate-950 p-5">

            <p className="leading-7 text-slate-400">

              Artificial intelligence can improve healthcare by helping
              doctors analyze medical information, supporting diagnosis,
              and optimizing hospital operations.

              <br />
              <br />

              AI can also help healthcare organizations process large
              amounts of patient data and identify useful patterns.

            </p>

          </div>

        </div>


        {/* Refined Response */}
        <div className="rounded-2xl border border-emerald-500/20 bg-slate-900 p-6">

          <div className="flex items-center justify-between">

            <div>

              <h2 className="text-xl font-semibold text-white">
                Refined Response
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                After CRISP refinement
              </p>

            </div>

            <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs text-emerald-400">
              95/100
            </span>

          </div>


          <div className="mt-6 rounded-xl border border-emerald-500/10 bg-slate-950 p-5">

            <p className="leading-7 text-slate-300">

              Artificial intelligence can improve healthcare by supporting
              diagnosis, personalized treatment, clinical decision-making,
              and hospital operations.

              <br />
              <br />

              For example, machine learning models can analyze medical
              images to assist with disease detection and can use patient
              records to identify potential health risks.

              <br />
              <br />

              AI can also optimize hospital resources through demand
              forecasting, appointment scheduling, and resource allocation.
              However, these systems should be used responsibly with
              appropriate human oversight, privacy protection, and safety
              measures.

            </p>

          </div>

        </div>

      </div>


      {/* Dimension Improvements */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div>

          <h2 className="text-xl font-semibold text-white">
            Dimension Improvements
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Quality changes after refinement.
          </p>

        </div>


        <div className="mt-6 space-y-5">

          {/* Accuracy */}
          <div>

            <div className="mb-2 flex justify-between">

              <span className="text-sm text-slate-400">
                Accuracy
              </span>

              <span className="text-sm text-white">
                88 → 94
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "94%" }}
              />

            </div>

          </div>


          {/* Completeness */}
          <div>

            <div className="mb-2 flex justify-between">

              <span className="text-sm text-slate-400">
                Completeness
              </span>

              <span className="text-sm text-white">
                82 → 95
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "95%" }}
              />

            </div>

          </div>


          {/* Reasoning */}
          <div>

            <div className="mb-2 flex justify-between">

              <span className="text-sm text-slate-400">
                Reasoning
              </span>

              <span className="text-sm text-white">
                79 → 93
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "93%" }}
              />

            </div>

          </div>


          {/* Clarity */}
          <div>

            <div className="mb-2 flex justify-between">

              <span className="text-sm text-slate-400">
                Clarity
              </span>

              <span className="text-sm text-white">
                91 → 96
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "96%" }}
              />

            </div>

          </div>


          {/* Safety */}
          <div>

            <div className="mb-2 flex justify-between">

              <span className="text-sm text-slate-400">
                Safety
              </span>

              <span className="text-sm text-white">
                96 → 98
              </span>

            </div>

            <div className="h-2 rounded-full bg-slate-800">

              <div
                className="h-full rounded-full bg-purple-600"
                style={{ width: "98%" }}
              />

            </div>

          </div>

        </div>

      </div>


      {/* Continue */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/final-response")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          View Final Response →
        </button>

      </div>

    </div>
  )
}

export default Comparison