import { useNavigate } from "react-router-dom"

function Decision() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Adaptive Decision
          </h1>

          <span className="rounded-full bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-400">
            Refinement Required
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          CRISP decides whether the response should be refined based on
          the evaluation score and quality threshold.
        </p>
      </div>


      {/* Decision Score */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="grid gap-6 md:grid-cols-2">

          {/* Overall Score */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6">

            <p className="text-sm text-slate-500">
              Overall Quality Score
            </p>

            <p className="mt-2 text-5xl font-bold text-white">
              87
              <span className="ml-2 text-lg font-normal text-slate-500">
                / 100
              </span>
            </p>

          </div>


          {/* Threshold */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-6">

            <p className="text-sm text-slate-500">
              Quality Threshold
            </p>

            <p className="mt-2 text-5xl font-bold text-purple-400">
              90
              <span className="ml-2 text-lg font-normal text-slate-500">
                / 100
              </span>
            </p>

          </div>

        </div>

      </div>


      {/* Decision Logic */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          Decision Logic
        </h2>

        <div className="mt-6 flex flex-col items-center gap-4 md:flex-row md:justify-center">

          <div className="rounded-xl border border-slate-800 bg-slate-950 px-6 py-4 text-center">

            <p className="text-xs text-slate-500">
              Current Score
            </p>

            <p className="mt-1 text-2xl font-bold text-white">
              87
            </p>

          </div>


          <div className="text-2xl text-slate-600">
            &lt;
          </div>


          <div className="rounded-xl border border-purple-500/20 bg-purple-500/5 px-6 py-4 text-center">

            <p className="text-xs text-slate-500">
              Required Threshold
            </p>

            <p className="mt-1 text-2xl font-bold text-purple-400">
              90
            </p>

          </div>


          <div className="text-2xl text-slate-600">
            →
          </div>


          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 px-6 py-4 text-center">

            <p className="text-xs text-slate-500">
              Decision
            </p>

            <p className="mt-1 text-2xl font-bold text-amber-400">
              Refine
            </p>

          </div>

        </div>

      </div>


      {/* Why Refinement */}
      <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-6">

        <h2 className="text-xl font-semibold text-white">
          Why refinement?
        </h2>

        <p className="mt-3 leading-7 text-slate-400">
          The current response achieved a quality score of 87, which is
          below the configured threshold of 90. CRISP therefore sends the
          response through the critique and refinement stages before
          delivering the final response.
        </p>

      </div>


      {/* Pipeline Status */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <h2 className="text-xl font-semibold text-white">
          CRISP Pipeline
        </h2>

        <div className="mt-6 grid gap-3 md:grid-cols-5">

          <div className="rounded-lg bg-slate-950 p-4 text-center">

            <p className="text-xs text-slate-500">
              01
            </p>

            <p className="mt-1 text-sm text-slate-300">
              Generate
            </p>

          </div>


          <div className="rounded-lg bg-slate-950 p-4 text-center">

            <p className="text-xs text-slate-500">
              02
            </p>

            <p className="mt-1 text-sm text-slate-300">
              Evaluate
            </p>

          </div>


          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-4 text-center">

            <p className="text-xs text-amber-500">
              03
            </p>

            <p className="mt-1 text-sm text-amber-400">
              Decide
            </p>

          </div>


          <div className="rounded-lg bg-slate-950 p-4 text-center">

            <p className="text-xs text-slate-500">
              04
            </p>

            <p className="mt-1 text-sm text-slate-300">
              Critique
            </p>

          </div>


          <div className="rounded-lg bg-slate-950 p-4 text-center">

            <p className="text-xs text-slate-500">
              05
            </p>

            <p className="mt-1 text-sm text-slate-300">
              Refine
            </p>

          </div>

        </div>

      </div>


      {/* Action */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/critique")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          Continue to Critique →
        </button>

      </div>

    </div>
  )
}

export default Decision