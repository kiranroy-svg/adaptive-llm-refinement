import { useNavigate } from "react-router-dom"

function InitialResponse() {
  const navigate = useNavigate()

  return (
    <div className="space-y-8">

      {/* Header */}
      <div>
        <div className="flex items-center gap-3">

          <h1 className="text-3xl font-bold text-white">
            Initial Response
          </h1>

          <span className="rounded-full bg-purple-500/10 px-3 py-1 text-xs font-medium text-purple-400">
            Generated
          </span>

        </div>

        <p className="mt-2 text-slate-400">
          This is the initial response generated before CRISP evaluation.
        </p>
      </div>


      {/* Original Query */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <p className="text-sm font-medium text-slate-500">
          Original Query
        </p>

        <p className="mt-3 leading-7 text-slate-300">
          Explain how artificial intelligence can be used in healthcare
          and how it can improve clinical and hospital operations.
        </p>

      </div>


      {/* Generated Response */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6">

        <div className="flex items-center justify-between">

          <div>

            <h2 className="text-xl font-semibold text-white">
              Generated Response
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Initial AI-generated response
            </p>

          </div>

          <span className="rounded-full bg-blue-500/10 px-3 py-1 text-xs text-blue-400">
            AI Generated
          </span>

        </div>


        <div className="mt-6 rounded-xl border border-slate-800 bg-slate-950 p-6">

          <p className="leading-8 text-slate-300">

            Artificial intelligence can improve healthcare by helping
            doctors analyze medical information, supporting diagnosis,
            and optimizing hospital operations.

            <br />
            <br />

            AI systems can process large amounts of patient data and
            identify patterns that may be useful for healthcare
            professionals. They can also support medical imaging,
            patient risk prediction, and resource management.

          </p>

        </div>

      </div>


      {/* Metadata */}
      <div className="grid gap-4 md:grid-cols-3">

        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">

          <p className="text-xs text-slate-500">
            Model
          </p>

          <p className="mt-2 font-medium text-white">
            CRISP-Grok
          </p>

        </div>


        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">

          <p className="text-xs text-slate-500">
            Response Time
          </p>

          <p className="mt-2 font-medium text-white">
            1.8 seconds
          </p>

        </div>


        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">

          <p className="text-xs text-slate-500">
            Tokens
          </p>

          <p className="mt-2 font-medium text-white">
            428
          </p>

        </div>

      </div>


      {/* Action */}
      <div className="flex justify-end">

        <button
          onClick={() => navigate("/evaluation")}
          className="rounded-lg bg-purple-600 px-6 py-3 font-semibold text-white transition hover:bg-purple-700"
        >
          Evaluate Response →
        </button>

      </div>

    </div>
  )
}

export default InitialResponse